//
// Created by os on 4/17/22.
//

#ifndef XV6_CONSUMERPRODUCER_CPP_Sync_API_TEST_H
#define XV6_CONSUMERPRODUCER_CPP_Sync_API_TEST_H

void producerConsumer_CPP_Sync_API();

#endif //XV6_CONSUMERPRODUCER_CPP_Sync_API_TEST_H
