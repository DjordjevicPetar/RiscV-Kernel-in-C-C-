#ifndef XV6_THREAD_C_API_TEST_HPP
#define XV6_THREAD_C_API_TEST_HPP

void Threads_C_API_test();

#endif //XV6_THREAD_C_API_TEST_HPP
