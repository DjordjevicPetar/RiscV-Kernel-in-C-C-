#ifndef XV6_SYSTEM_MODE_TEST_HPP
#define XV6_SYSTEM_MODE_TEST_HPP

void System_Mode_test();

#endif //XV6_SYSTEM_MODE_TEST_HPP
